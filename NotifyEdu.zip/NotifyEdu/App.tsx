import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import LoginPage from './components/auth/LoginPage';
import SchoolDashboard from './components/school/SchoolDashboard';
import StudentDashboard from './components/student/StudentDashboard';
import SuperAdminDashboard from './components/admin/SuperAdminDashboard';
import { UserType } from './types';

const AppRoutes: React.FC = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  const getHomeRedirect = () => {
    if (!user) return "/login";
    switch (user.type) {
      case UserType.School:
        return "/school";
      case UserType.Student:
        return "/student";
      case UserType.SuperAdmin:
        return "/portal-admin-console";
      default:
        return "/login";
    }
  };

  return (
    <Routes>
      <Route
        path="/login"
        element={!user ? <LoginPage /> : <Navigate to={getHomeRedirect()} />}
      />
      <Route
        path="/"
        element={<Navigate to={getHomeRedirect()} />}
      />
      <Route
        path="/school"
        element={
          user && user.type === UserType.School ? (
            <SchoolDashboard />
          ) : (
            <Navigate to="/login" />
          )
        }
      />
      <Route
        path="/student"
        element={
          user && user.type === UserType.Student ? (
            <StudentDashboard />
          ) : (
            <Navigate to="/login" />
          )
        }
      />
      <Route
        path="/portal-admin-console"
        element={
          user && user.type === UserType.SuperAdmin ? (
            <SuperAdminDashboard />
          ) : (
            <Navigate to="/login" />
          )
        }
      />
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
};

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <AuthProvider>
        <HashRouter>
          <div className="min-h-screen bg-base-200 dark:bg-gray-900 text-neutral dark:text-gray-200">
            <AppRoutes />
          </div>
        </HashRouter>
      </AuthProvider>
    </ThemeProvider>
  );
};

export default App;