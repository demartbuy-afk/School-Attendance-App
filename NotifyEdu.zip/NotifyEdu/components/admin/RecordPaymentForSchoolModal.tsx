import React, { useState } from 'react';
import { api } from '../../services/api';
import { School } from '../../types';

interface RecordPaymentForSchoolModalProps {
  isOpen: boolean;
  onClose: () => void;
  school: School;
  token: string;
  onSuccess: (school: School) => void;
}

const RecordPaymentForSchoolModal: React.FC<RecordPaymentForSchoolModalProps> = ({ isOpen, onClose, school, token, onSuccess }) => {
  const [months, setMonths] = useState<number>(0);
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const plans = [
    { name: '1 Month', value: 1, price: 599 },
    { name: '6 Months', value: 6, price: 3235 },
    { name: '12 Months', value: 12, price: 5750 },
  ];

  const handleSelectPlan = (plan: { value: number, price: number }) => {
    setMonths(plan.value);
    setAmount(plan.price.toString());
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (months === 0 || !amount) {
        setError("Please select a plan and enter the amount paid.");
        return;
    }
    setLoading(true);
    setError(null);
    try {
      const updatedSchool = await api.updateSubscription(token, school.id, months);
      // Note: In a real app, you would also save the payment record (amount, notes) to a payments collection.
      onSuccess(updatedSchool);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg">
        <form onSubmit={handleSubmit}>
            <div className="p-6 border-b dark:border-gray-700 flex justify-between items-center">
              <h3 className="text-xl font-semibold leading-6 text-gray-900 dark:text-gray-100">
                Record Payment for: {school.name}
              </h3>
              <button type="button" onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">&times;</button>
            </div>
            
            <div className="p-6 space-y-6">
                <div className="bg-gray-50 dark:bg-gray-700/50 p-3 rounded-md text-center">
                    <p className="text-sm text-gray-600 dark:text-gray-400">Current Subscription Expiry</p>
                    <p className="text-lg font-bold text-neutral dark:text-gray-200">{new Date(school.subscription_expiry_date).toLocaleDateString()}</p>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Select Subscription Plan</label>
                    <div className="grid grid-cols-3 gap-3">
                        {plans.map(plan => (
                             <button
                                type="button"
                                key={plan.value}
                                onClick={() => handleSelectPlan(plan)}
                                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${months === plan.value ? 'bg-primary text-white' : 'bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600'}`}
                             >
                                {plan.name}
                            </button>
                        ))}
                    </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="amountPaid" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Amount Paid (₹)</label>
                        <input
                          type="number"
                          id="amountPaid"
                          value={amount}
                          onChange={(e) => setAmount(e.target.value)}
                          required
                          className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-gray-900 dark:text-gray-200 focus:outline-none focus:ring-primary focus:border-primary"
                        />
                    </div>
                     <div>
                        <label htmlFor="paymentNotes" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Notes (Optional)</label>
                        <input
                          type="text"
                          id="paymentNotes"
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          placeholder="e.g., UPI Transaction ID"
                          className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-gray-900 dark:text-gray-200 focus:outline-none focus:ring-primary focus:border-primary"
                        />
                    </div>
                </div>

                {error && <p className="text-red-500 text-sm text-center">{error}</p>}
            </div>

            <div className="px-6 py-4 bg-gray-50 dark:bg-gray-900 flex justify-end space-x-3">
                <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm hover:bg-gray-50 dark:hover:bg-gray-600"
                >
                    Cancel
                </button>
                <button
                    type="submit"
                    disabled={loading || months === 0 || !amount}
                    className="px-4 py-2 text-sm font-medium text-white bg-primary rounded-md shadow-sm hover:bg-primary-hover disabled:bg-indigo-300 dark:disabled:bg-indigo-800"
                >
                    {loading ? 'Processing...' : 'Confirm & Extend'}
                </button>
            </div>
        </form>
      </div>
    </div>
  );
};

export default RecordPaymentForSchoolModal;