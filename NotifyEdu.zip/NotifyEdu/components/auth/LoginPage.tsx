import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';

type LoginMode = 'school' | 'student' | 'admin';

const LoginPage: React.FC = () => {
  const location = useLocation();
  const [mode, setMode] = useState<LoginMode>('school');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  
  const [schoolId, setSchoolId] = useState('');
  const [schoolPassword, setSchoolPassword] = useState('');
  
  const [studentId, setStudentId] = useState('');
  const [studentPassword, setStudentPassword] = useState('');

  const [adminPassword, setAdminPassword] = useState('');

  const { login } = useAuth();

  useEffect(() => {
      if (location.pathname === '/portal-admin-console') {
          setMode('admin');
      }
  }, [location]);

  const performLogin = async (loginMode: LoginMode, id: string, password?: string) => {
    setLoading(true);
    setError(null);
    try {
      let user;
      if (loginMode === 'school' && password) {
        user = await api.loginSchool(id, password);
      } else if (loginMode === 'student' && password) {
        user = await api.loginStudent(id, password);
      } else if (loginMode === 'admin') {
        user = await api.loginSuperAdmin(id);
      }
      
      if(user) {
        login(user);
      } else {
        throw new Error("Login failed. Please check your credentials.");
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'school') {
      performLogin('school', schoolId, schoolPassword);
    } else if (mode === 'student') {
      performLogin('student', studentId, studentPassword);
    } else { // admin
      performLogin('admin', adminPassword);
    }
  };
  
  const isAdminRoute = location.pathname === '/portal-admin-console';

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900 p-4">
      <div className="w-full max-w-md bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 space-y-6">
        <div className="text-center">
            <h1 className="text-3xl font-bold text-primary">
              {isAdminRoute ? 'Admin Console' : 'NotifyEdu'}
            </h1>
            <p className="text-gray-500 dark:text-gray-400 mt-2">Sign in to continue</p>
        </div>
        
        {!isAdminRoute && (
          <div className="flex border-b border-gray-200 dark:border-gray-700">
            <button
              onClick={() => setMode('school')}
              className={`flex-1 py-3 text-sm font-semibold transition-colors duration-300 ${mode === 'school' ? 'text-primary border-b-2 border-primary' : 'text-gray-500 dark:text-gray-400 hover:text-primary'}`}
            >
              School Portal
            </button>
            <button
              onClick={() => setMode('student')}
              className={`flex-1 py-3 text-sm font-semibold transition-colors duration-300 ${mode === 'student' ? 'text-primary border-b-2 border-primary' : 'text-gray-500 dark:text-gray-400 hover:text-primary'}`}
            >
              Student Portal
            </button>
          </div>
        )}

        <div className="bg-blue-50 dark:bg-blue-900/20 border-l-4 border-blue-500 text-blue-700 dark:text-blue-300 p-4 rounded-r-lg" role="alert">
            <p className="text-sm">
                Welcome! Please enter your credentials to access your dashboard.
                Contact your administrator if you have trouble logging in.
            </p>
        </div>


        <form onSubmit={handleLogin} className="space-y-6">
          {mode === 'school' ? (
            <>
              <div>
                <label htmlFor="school_id" className="block text-sm font-medium text-gray-700 dark:text-gray-300">School ID</label>
                <input id="school_id" type="text" value={schoolId} onChange={e => setSchoolId(e.target.value)} required className="mt-1 block w-full px-4 py-3 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm text-gray-900 dark:text-gray-200 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-primary focus:border-primary" placeholder="Enter school ID"/>
              </div>
              <div>
                <label htmlFor="school_password" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Password</label>
                <input id="school_password" type="password" value={schoolPassword} onChange={e => setSchoolPassword(e.target.value)} required className="mt-1 block w-full px-4 py-3 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm text-gray-900 dark:text-gray-200 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-primary focus:border-primary" placeholder="••••••••"/>
              </div>
            </>
          ) : mode === 'student' ? (
            <>
              <div>
                <label htmlFor="student_id" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Student ID</label>
                <input id="student_id" type="text" value={studentId} onChange={e => setStudentId(e.target.value)} required className="mt-1 block w-full px-4 py-3 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm text-gray-900 dark:text-gray-200 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-primary focus:border-primary" placeholder="Enter student ID"/>
              </div>
              <div>
                <label htmlFor="student_password" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Password</label>
                <input id="student_password" type="password" value={studentPassword} onChange={e => setStudentPassword(e.target.value)} required className="mt-1 block w-full px-4 py-3 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm text-gray-900 dark:text-gray-200 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-primary focus:border-primary" placeholder="••••••••"/>
              </div>
            </>
          ) : ( // Admin mode
            <div>
              <label htmlFor="admin_password" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Admin Password</label>
              <input id="admin_password" type="password" value={adminPassword} onChange={e => setAdminPassword(e.target.value)} required className="mt-1 block w-full px-4 py-3 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm text-gray-900 dark:text-gray-200 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-primary focus:border-primary" placeholder="••••••••"/>
            </div>
          )}
          
          {error && <p className="text-sm text-red-500 text-center">{error}</p>}

          <div>
            <button type="submit" disabled={loading} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-focus disabled:bg-indigo-300 dark:disabled:bg-indigo-800 transition-colors">
              {loading ? <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div> : 'Sign In'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;