import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';
import { Student, AttendanceLog, AttendanceStatus } from '../../types';
import ManualAttendance from './ManualAttendance';
import QrScanner from './QrScanner';
import FaceRecognition from './FaceRecognition';
import AttendanceLogList from './AttendanceLogList';

interface AttendanceManagerProps {
  students: Student[];
  showToast: (message: string) => void;
}

type AttendanceTab = 'manual' | 'qr' | 'face';

const AttendanceManager: React.FC<AttendanceManagerProps> = ({ students, showToast }) => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<AttendanceTab>('manual');
  const [logs, setLogs] = useState<AttendanceLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [absenteeLoading, setAbsenteeLoading] = useState(false);

  const fetchTodaysAttendance = useCallback(async () => {
    if (user) {
      setLoading(true);
      setError(null);
      try {
        const attendanceData = await api.getTodaysAttendance(user.id, user.token);
        setLogs(attendanceData);
      } catch (err) {
        setError((err as Error).message);
      } finally {
        setLoading(false);
      }
    }
  }, [user]);

  useEffect(() => {
    fetchTodaysAttendance();
  }, [fetchTodaysAttendance]);

  const handleAttendanceMarked = useCallback((newLog: AttendanceLog) => {
    // Avoid duplicates if log already exists
    if (!logs.some(l => l.log_id === newLog.log_id)) {
      setLogs(prevLogs => [newLog, ...prevLogs]);
    }
    showToast(`Attendance recorded for ${newLog.student_name}.`);
  }, [showToast, logs]);
  
  const handleSendAbsenteeNotifications = async () => {
    if (!user) return;
    setAbsenteeLoading(true);

    try {
        // Find students who have an 'IN' or 'OUT' log for today
        const presentStudentIds = new Set(
            logs
            .filter(log => log.status === AttendanceStatus.IN || log.status === AttendanceStatus.OUT)
            .map(log => log.student_id)
        );
        
        // Find students who are not in the present list
        const absentStudentIds = students
            .filter(student => !presentStudentIds.has(student.student_id))
            .map(student => student.student_id);

        if (absentStudentIds.length === 0) {
            showToast("All students are accounted for today.");
            setAbsenteeLoading(false);
            return;
        }

        const newAbsentLogs = await api.markStudentsAsAbsent(user.id, user.token, absentStudentIds);
        
        // Add new logs to the list, avoiding duplicates
        setLogs(prevLogs => {
            const existingLogIds = new Set(prevLogs.map(l => l.log_id));
            const uniqueNewLogs = newAbsentLogs.filter(l => !existingLogIds.has(l.log_id));
            return [...uniqueNewLogs, ...prevLogs].sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        });
        
        showToast(`Sent absentee notifications to ${absentStudentIds.length} parents.`);

    } catch (err) {
        showToast(`Error: ${(err as Error).message}`);
    } finally {
        setAbsenteeLoading(false);
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'manual':
        return <ManualAttendance students={students} onAttendanceMarked={handleAttendanceMarked} />;
      case 'qr':
        return <QrScanner onQrScanned={handleAttendanceMarked} />;
      case 'face':
        return <FaceRecognition onFaceRecognized={handleAttendanceMarked} />;
      default:
        return null;
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-1">
        <h3 className="text-xl font-bold text-neutral dark:text-gray-200 mb-4">Mark Attendance</h3>
        <div className="mb-4 border-b border-gray-200 dark:border-gray-700">
            <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                <button onClick={() => setActiveTab('manual')} className={`${activeTab === 'manual' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-200'} whitespace-nowrap pb-2 px-1 border-b-2 font-medium text-sm`}>
                    Manual
                </button>
                <button onClick={() => setActiveTab('qr')} className={`${activeTab === 'qr' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-200'} whitespace-nowrap pb-2 px-1 border-b-2 font-medium text-sm`}>
                    QR Scan
                </button>
                <button onClick={() => setActiveTab('face')} className={`${activeTab === 'face' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-200'} whitespace-nowrap pb-2 px-1 border-b-2 font-medium text-sm`}>
                    Face ID
                </button>
            </nav>
        </div>
        <div className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
            {renderTabContent()}
        </div>
      </div>
      <div className="lg:col-span-2">
        <div className="flex justify-between items-center mb-4 flex-wrap gap-2">
            <h3 className="text-xl font-bold text-neutral dark:text-gray-200">Today's Attendance Log</h3>
            <button
              onClick={handleSendAbsenteeNotifications}
              disabled={absenteeLoading}
              className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md shadow-sm hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:bg-red-400"
            >
              {absenteeLoading ? 'Processing...' : 'Send Absentee Notifications'}
            </button>
        </div>
        {loading ? (
            <div className="flex items-center justify-center pt-10">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-primary"></div>
            </div>
        ) : error ? (
            <div className="text-center text-red-500 bg-red-100 dark:bg-red-900 dark:text-red-200 p-4 rounded-lg">{error}</div>
        ) : (
            <AttendanceLogList logs={logs} />
        )}
      </div>
    </div>
  );
};

export default AttendanceManager;