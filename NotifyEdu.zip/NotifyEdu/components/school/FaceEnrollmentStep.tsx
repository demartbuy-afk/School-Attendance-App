import React, { useRef, useState, useCallback } from 'react';
import Webcam from 'react-webcam';
import { api } from '../../services/api';
import { Student } from '../../types';

interface FaceEnrollmentStepProps {
  student: Student;
  token: string;
  onComplete: (enrolled: boolean) => void;
}

const FaceEnrollmentStep: React.FC<FaceEnrollmentStepProps> = ({ student, token, onComplete }) => {
  const webcamRef = useRef<Webcam>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleEnrollFace = useCallback(async () => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (!imageSrc) {
      setError("Could not capture image. Please ensure camera is enabled.");
      return;
    }
    
    setLoading(true);
    setError(null);
    try {
      await api.enrollFace(student.student_id, token);
      onComplete(true);
    } catch (err) {
      setError((err as Error).message || "Enrollment failed. Please try again.");
      setLoading(false);
    }
  }, [webcamRef, student, token, onComplete]);
  
  const videoConstraints = {
    width: 320,
    height: 320,
    facingMode: "user"
  };

  return (
    <div className="w-full text-center space-y-4">
        <p className="text-gray-600 dark:text-gray-400">Enroll face for touchless attendance (optional).</p>
        <div className="w-48 h-48 sm:w-64 sm:h-64 rounded-full overflow-hidden border-4 border-dashed border-primary mx-auto flex items-center justify-center">
             <Webcam
                audio={false}
                ref={webcamRef}
                screenshotFormat="image/jpeg"
                width={320}
                height={320}
                videoConstraints={videoConstraints}
                mirrored
                className="scale-150"
            />
        </div>
        <div className="h-5">
            {error && <p className="text-sm text-center text-red-500">{error}</p>}
        </div>
        <div className="flex justify-center space-x-4 pt-4">
            <button
                onClick={() => onComplete(false)}
                disabled={loading}
                className="px-6 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm hover:bg-gray-50 dark:hover:bg-gray-600"
            >
                Skip For Now
            </button>
             <button
                onClick={handleEnrollFace}
                disabled={loading}
                className="px-6 py-2 text-sm font-medium text-white bg-secondary rounded-md shadow-sm hover:bg-secondary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary-focus disabled:bg-green-300 dark:disabled:bg-green-800"
            >
                {loading ? 'Enrolling...' : 'Capture & Enroll'}
            </button>
        </div>
    </div>
  );
};

export default FaceEnrollmentStep;