import React, { useRef, useState, useCallback } from 'react';
import Webcam from 'react-webcam';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';
import { AttendanceLog } from '../../types';

interface FaceRecognitionProps {
  onFaceRecognized: (log: AttendanceLog) => void;
}

const FaceRecognition: React.FC<FaceRecognitionProps> = ({ onFaceRecognized }) => {
  const { user } = useAuth();
  const webcamRef = useRef<Webcam>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const captureAndRecognize = useCallback(async () => {
    if (loading || !user) return;
    
    const imageSrc = webcamRef.current?.getScreenshot();
    if (!imageSrc) {
      setError("Could not capture image from webcam.");
      return;
    }
    
    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const base64Image = imageSrc.split(',')[1];
      const { log, studentName } = await api.recognizeFace(user.id, user.token, base64Image);
      setSuccess(`Welcome, ${studentName}! Attendance marked.`);
      onFaceRecognized(log);
    } catch (err) {
      setError((err as Error).message || "Face not recognized. Please try again.");
    } finally {
      setLoading(false);
      setTimeout(() => {
        setSuccess(null);
        setError(null);
      }, 3000);
    }
  }, [webcamRef, user, onFaceRecognized, loading]);
  
  const videoConstraints = {
    width: 320,
    height: 320,
    facingMode: "user"
  };

  return (
    <div className="space-y-4 flex flex-col items-center">
        <div className="w-48 h-48 sm:w-64 sm:h-64 rounded-full overflow-hidden border-4 border-dashed border-primary flex items-center justify-center">
             <Webcam
                audio={false}
                ref={webcamRef}
                screenshotFormat="image/jpeg"
                width={320}
                height={320}
                videoConstraints={videoConstraints}
                mirrored
                className="scale-150"
            />
        </div>
      <button
        onClick={captureAndRecognize}
        disabled={loading}
        className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-focus disabled:bg-gray-400 dark:disabled:bg-gray-600 transition-colors"
      >
        {loading ? 'Recognizing...' : 'Recognize & Mark'}
      </button>
      <div className="h-5 mt-2">
        {error && <p className="text-sm text-center text-red-500">{error}</p>}
        {success && <p className="text-sm text-center text-green-500">{success}</p>}
      </div>
    </div>
  );
};

export default FaceRecognition;