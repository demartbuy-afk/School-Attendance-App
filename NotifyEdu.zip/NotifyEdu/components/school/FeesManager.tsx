import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Student } from '../../types';
import { api } from '../../services/api';

interface FeesManagerProps {
  students: Student[];
  onUpdate: () => void;
  showToast: (message: string) => void;
}

const FeesManager: React.FC<FeesManagerProps> = ({ students, onUpdate, showToast }) => {
    const { user } = useAuth();
    const [editingStudentId, setEditingStudentId] = useState<string | null>(null);
    const [feeData, setFeeData] = useState<{ [key: string]: { total: number, paid: number } }>({});

    useEffect(() => {
        // Initialize local state when students prop changes
        const initialData = students.reduce((acc, student) => {
            acc[student.student_id] = { total: student.total_fees, paid: student.fees_paid };
            return acc;
        }, {} as { [key: string]: { total: number, paid: number } });
        setFeeData(initialData);
    }, [students]);

    const handleEdit = (student: Student) => {
        setEditingStudentId(student.student_id);
    };

    const handleCancel = () => {
        setEditingStudentId(null);
        // Reset local data to match original prop data
        const originalStudent = students.find(s => s.student_id === editingStudentId);
        if (originalStudent) {
            setFeeData(prev => ({
                ...prev,
                [originalStudent.student_id]: { total: originalStudent.total_fees, paid: originalStudent.fees_paid }
            }));
        }
    };
    
    const handleSave = async (studentId: string) => {
        if (!user) return;
        const student = students.find(s => s.student_id === studentId);
        const { total, paid } = feeData[studentId];
        if (!student || total === undefined || paid === undefined) return;
        
        try {
            await api.updateStudentFees(user.token, studentId, total, paid);
            showToast(`Fees updated for ${student.name}.`);
            setEditingStudentId(null);
            onUpdate(); // Refresh data from parent
        } catch (error) {
            showToast(`Failed to update fees for ${student.name}.`);
        }
    };
    
    const handleInputChange = (studentId: string, field: 'total' | 'paid', value: string) => {
        const numValue = parseInt(value, 10);
        if (!isNaN(numValue) || value === '') {
            setFeeData(prev => ({
                ...prev,
                [studentId]: {
                    ...prev[studentId],
                    [field]: isNaN(numValue) ? 0 : numValue
                }
            }));
        }
    };

    const getFeeStatusColor = (paid: number, total: number) => {
        if (total === 0 && paid === 0) return 'bg-gray-100 text-gray-800 dark:bg-gray-600 dark:text-gray-200';
        if (paid >= total) return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
        if (paid === 0) return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
    };

    return (
        <div>
            <h2 className="text-2xl font-bold text-neutral dark:text-gray-200 mb-4">Fees Management</h2>
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Name</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Class</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Total Fees</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Fees Paid</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Balance</th>
                        <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Status</th>
                        <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Action</th>
                    </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    {students.map((student) => {
                        const isEditing = editingStudentId === student.student_id;
                        const currentData = feeData[student.student_id] || { total: student.total_fees, paid: student.fees_paid };
                        const balance = currentData.total - currentData.paid;

                        return (
                            <tr key={student.student_id}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-gray-100">{student.name}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{student.class}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                                    {isEditing ? (
                                        <input type="number" value={currentData.total} onChange={(e) => handleInputChange(student.student_id, 'total', e.target.value)} className="w-24 p-1 rounded bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600"/>
                                    ) : `₹${currentData.total.toLocaleString()}`}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600 dark:text-green-400">
                                    {isEditing ? (
                                        <input type="number" value={currentData.paid} onChange={(e) => handleInputChange(student.student_id, 'paid', e.target.value)} className="w-24 p-1 rounded bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600"/>
                                    ) : `₹${currentData.paid.toLocaleString()}`}
                                </td>
                                <td className={`px-6 py-4 whitespace-nowrap text-sm font-semibold ${balance > 0 ? 'text-red-600 dark:text-red-400' : 'text-gray-500 dark:text-gray-300'}`}>₹{balance.toLocaleString()}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-center text-sm">
                                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getFeeStatusColor(currentData.paid, currentData.total)}`}>
                                        {currentData.paid >= currentData.total ? 'Paid' : (currentData.paid > 0 ? 'Partial' : 'Unpaid')}
                                    </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-center text-sm">
                                    {isEditing ? (
                                        <div className="flex justify-center space-x-2">
                                            <button onClick={() => handleSave(student.student_id)} className="px-2 py-1 text-xs bg-green-500 text-white rounded hover:bg-green-600">Save</button>
                                            <button onClick={handleCancel} className="px-2 py-1 text-xs bg-gray-500 text-white rounded hover:bg-gray-600">Cancel</button>
                                        </div>
                                    ) : (
                                        <button onClick={() => handleEdit(student)} className="px-3 py-1 text-xs bg-primary text-white font-semibold rounded-md shadow-sm hover:bg-primary-hover focus:outline-none">
                                            Edit
                                        </button>
                                    )}
                                </td>
                            </tr>
                        )
                    })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default FeesManager;