import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';
import { Student, AttendanceStatus, AttendanceLog } from '../../types';

interface ManualAttendanceProps {
  students: Student[];
  onAttendanceMarked: (log: AttendanceLog) => void;
}

const ManualAttendance: React.FC<ManualAttendanceProps> = ({ students, onAttendanceMarked }) => {
  const { user } = useAuth();
  const [selectedStudent, setSelectedStudent] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    // Pre-populate dropdown if students list is available
    if (students.length > 0) {
      setSelectedStudent('');
    }
  }, [students]);

  const handleMarkAttendance = async (status: AttendanceStatus) => {
    if (!selectedStudent || !user) {
        setError("Please select a student.");
        return;
    };
    setLoading(true);
    setError(null);
    setSuccess(null);
    try {
      const log = await api.markAttendance(user.id, user.token, selectedStudent, status);
      const studentName = students.find(s => s.student_id === selectedStudent)?.name;
      setSuccess(`${studentName} marked as ${status}`);
      onAttendanceMarked(log);
      setSelectedStudent(''); // Reset dropdown
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
      setTimeout(() => {
        setSuccess(null);
        setError(null);
      }, 3000);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <label htmlFor="student-select" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          Select Student
        </label>
        <select
          id="student-select"
          value={selectedStudent}
          onChange={(e) => setSelectedStudent(e.target.value)}
          className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-200 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md"
        >
          <option value="" disabled>-- Choose a student --</option>
          {students.map((student) => (
            <option key={student.student_id} value={student.student_id}>
              {student.name} ({student.roll_no})
            </option>
          ))}
        </select>
      </div>
      
      <div className="flex space-x-4">
        <button
          onClick={() => handleMarkAttendance(AttendanceStatus.IN)}
          disabled={!selectedStudent || loading}
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:bg-gray-400 dark:disabled:bg-gray-600 transition-colors"
        >
          Mark IN
        </button>
        <button
          onClick={() => handleMarkAttendance(AttendanceStatus.OUT)}
          disabled={!selectedStudent || loading}
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:bg-gray-400 dark:disabled:bg-gray-600 transition-colors"
        >
          Mark OUT
        </button>
      </div>

      <div className="h-5 mt-2">
        {loading && <p className="text-sm text-center text-gray-500 dark:text-gray-400">Processing...</p>}
        {error && <p className="text-sm text-center text-red-500">{error}</p>}
        {success && <p className="text-sm text-center text-green-500">{success}</p>}
      </div>
    </div>
  );
};

export default ManualAttendance;