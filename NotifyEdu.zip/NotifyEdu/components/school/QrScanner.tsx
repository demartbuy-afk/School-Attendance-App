import React, { useState, useEffect, useRef } from 'react';
import { Html5QrcodeScanner, Html5QrcodeScanType } from 'html5-qrcode';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';
import { AttendanceLog } from '../../types';

interface QrScannerProps {
  onQrScanned: (log: AttendanceLog) => void;
}

const QrScanner: React.FC<QrScannerProps> = ({ onQrScanned }) => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);
  const readerId = "qr-reader";

  useEffect(() => {
    let isMounted = true;
    
    const scanner = new Html5QrcodeScanner(
      readerId,
      { 
        fps: 10, 
        qrbox: { width: 250, height: 250 },
        supportedScanTypes: [Html5QrcodeScanType.SCAN_TYPE_CAMERA], // Force camera-only scanning
      },
      false // verbose
    );
    scannerRef.current = scanner;

    const onScanSuccess = async (decodedText: string) => {
      if (loading || !user) return;
      
      setLoading(true);
      setError(null);
      setSuccess(null);
      
      // State 2 is SCANNING. Check if the scanner is active before pausing.
      if (scanner.getState() === 2) {
        try {
          scanner.pause(true);
        } catch (e) {
          console.warn("Could not pause scanner.", e);
        }
      }

      try {
        const { log, studentName } = await api.markAttendanceByQr(user.id, user.token, decodedText);
        setSuccess(`Attendance marked for ${studentName}`);
        onQrScanned(log);
      } catch (err) {
        setError((err as Error).message || "Invalid QR Code.");
      } finally {
        setLoading(false);
        setTimeout(() => {
          if (isMounted) {
            setSuccess(null);
            setError(null);
            // State 3 is PAUSED. Check if it's paused before resuming.
            if (scanner.getState() === 3) {
               try {
                 scanner.resume();
               } catch(e) {
                 console.warn("Could not resume scanner.", e);
               }
            }
          }
        }, 3000);
      }
    };

    scanner.render(onScanSuccess, (errorMessage) => {
        // handle scan failure, usually better to do nothing here.
    });

    return () => {
        isMounted = false;
        if (scannerRef.current) {
            scannerRef.current.clear().catch(err => console.error("Failed to clear scanner", err));
            scannerRef.current = null;
        }
    };
  }, [user, onQrScanned]);

  return (
    <div className="space-y-4 text-center">
      <p className="text-sm text-gray-500 dark:text-gray-400">Point the camera at a student's QR code.</p>
      <div id={readerId} className="w-full"></div>
      <div className="h-5 mt-2">
        {loading && <p className="text-sm text-gray-500 dark:text-gray-400">Verifying QR Code...</p>}
        {error && <p className="text-sm text-red-500">{error}</p>}
        {success && <p className="text-sm text-green-500">{success}</p>}
      </div>
    </div>
  );
};

export default QrScanner;