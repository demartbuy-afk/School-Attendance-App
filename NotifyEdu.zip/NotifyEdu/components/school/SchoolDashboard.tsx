import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';
// FIX: Import UserType to use enum for role checking instead of a hardcoded string.
import { Student, School, UserType } from '../../types';
import Header from '../common/Header';
import StudentList from './StudentList';
import AddStudentModal from './AddStudentModal';
import ViewStudentQrModal from './ViewStudentQrModal';
import SendMessageModal from './SendMessageModal';
import DeleteStudentModal from './DeleteStudentModal';
import AttendanceManager from './AttendanceManager';
import FeesManager from './FeesManager';
import ComplaintsManager from './ComplaintsManager';
import BillingStatusBanner from './BillingStatusBanner';
import LockedAccountView from './LockedAccountView';
import SettingsManager from './SettingsManager';
import SubscriptionManager from './SubscriptionManager';

type SchoolTab = 'students' | 'attendance' | 'fees' | 'complaints' | 'settings' | 'subscription';

const SchoolDashboard: React.FC = () => {
  const { user, login } = useAuth();
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<SchoolTab>('students');

  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [viewingQrStudent, setViewingQrStudent] = useState<Student | null>(null);
  const [messagingStudent, setMessagingStudent] = useState<Student | null>(null);
  const [deletingStudent, setDeletingStudent] = useState<Student | null>(null);
  const [toastMessage, setToastMessage] = useState<string>('');

  const schoolUser = user as School;

  const showToast = useCallback((message: string) => {
    setToastMessage(message);
    setTimeout(() => setToastMessage(''), 3000);
  }, []);

  const fetchStudents = useCallback(async () => {
    if (user) {
      setLoading(true);
      setError(null);
      try {
        const studentData = await api.getSchoolStudents(user.id, user.token);
        setStudents(studentData);
      } catch (err) {
        setError((err as Error).message);
      } finally {
        setLoading(false);
      }
    }
  }, [user]);

  useEffect(() => {
    fetchStudents();
  }, [fetchStudents]);
  
  const handleStudentAdded = (newStudent: Student) => {
    setStudents(prev => [...prev, newStudent]);
    // The modal flow continues, but we add to the list instantly.
  };

  const handleStudentDeleted = () => {
      if (!deletingStudent) return;
      showToast(`Student ${deletingStudent.name} deleted successfully.`);
      setStudents(prev => prev.filter(s => s.student_id !== deletingStudent.student_id));
      setDeletingStudent(null);
  };

  const handleSubscriptionUpdated = (updatedSchool: School) => {
    // Re-login with updated user data to refresh context and local storage
    login(updatedSchool);
    showToast('Subscription updated successfully!');
  };

  // FIX: Use UserType enum for consistent and type-safe role checking.
  if (!user || user.type !== UserType.School) {
    return null; // Or a redirect component
  }
  
  if (user.status === 'LOCKED') {
      return (
          <>
              <Header />
              <LockedAccountView onRenew={() => setActiveTab('subscription')} />
          </>
      );
  }

  const renderContent = () => {
    if (loading && activeTab !== 'settings' && activeTab !== 'subscription') {
      return (
        <div className="flex items-center justify-center pt-20">
          <div className="animate-spin rounded-full h-24 w-24 border-t-2 border-b-2 border-primary"></div>
        </div>
      );
    }
    if (error) {
      return <div className="text-center text-red-500 bg-red-100 dark:bg-red-900 dark:text-red-200 p-4 rounded-lg">{error}</div>;
    }

    switch (activeTab) {
      case 'students':
        return (
          <div>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-neutral dark:text-gray-200">Manage Students</h2>
                <button onClick={() => setAddModalOpen(true)} className="px-4 py-2 bg-primary text-white font-semibold rounded-lg shadow-md hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-75">
                    + Add Student
                </button>
            </div>
            <StudentList 
                students={students} 
                onViewQr={setViewingQrStudent} 
                onSendMessage={setMessagingStudent}
                onDelete={setDeletingStudent}
            />
          </div>
        );
      case 'attendance':
        return <AttendanceManager students={students} showToast={showToast} />;
      case 'fees':
        return <FeesManager students={students} onUpdate={fetchStudents} showToast={showToast} />;
      case 'complaints':
        return <ComplaintsManager />;
      case 'settings':
        return <SettingsManager showToast={showToast} />;
      case 'subscription':
        return <SubscriptionManager 
                  school={schoolUser}
                  onSubscriptionUpdate={handleSubscriptionUpdated}
                  showToast={showToast} 
                />;
      default:
        return null;
    }
  };

  return (
    <>
      <Header />
      <main className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <BillingStatusBanner expiryDate={schoolUser.subscription_expiry_date} />
        <div className="mt-6">
            <div className="border-b border-gray-200 dark:border-gray-700">
                <nav className="-mb-px flex space-x-8 overflow-x-auto" aria-label="Tabs">
                    <button onClick={() => setActiveTab('students')} className={`${activeTab === 'students' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:border-gray-600'} flex-shrink-0 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}>
                        Students
                    </button>
                    <button onClick={() => setActiveTab('attendance')} className={`${activeTab === 'attendance' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:border-gray-600'} flex-shrink-0 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}>
                        Attendance
                    </button>
                    <button onClick={() => setActiveTab('fees')} className={`${activeTab === 'fees' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:border-gray-600'} flex-shrink-0 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}>
                        Fees
                    </button>
                     <button onClick={() => setActiveTab('complaints')} className={`${activeTab === 'complaints' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:border-gray-600'} flex-shrink-0 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}>
                        Complaints
                    </button>
                    <button onClick={() => setActiveTab('subscription')} className={`${activeTab === 'subscription' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:border-gray-600'} flex-shrink-0 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}>
                        Subscription
                    </button>
                    <button onClick={() => setActiveTab('settings')} className={`${activeTab === 'settings' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:border-gray-600'} flex-shrink-0 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}>
                        Settings
                    </button>
                </nav>
            </div>
            <div className="mt-8 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                {renderContent()}
            </div>
        </div>
      </main>

      {isAddModalOpen && user && (
        <AddStudentModal
          isOpen={isAddModalOpen}
          onClose={() => setAddModalOpen(false)}
          schoolId={user.id}
          token={user.token}
          onStudentAdded={handleStudentAdded}
        />
      )}
      {viewingQrStudent && (
        <ViewStudentQrModal 
            isOpen={!!viewingQrStudent}
            onClose={() => setViewingQrStudent(null)}
            student={viewingQrStudent}
        />
      )}
      {messagingStudent && user && (
          <SendMessageModal 
            isOpen={!!messagingStudent}
            onClose={() => setMessagingStudent(null)}
            student={messagingStudent}
            token={user.token}
            onSuccess={() => {
                showToast(`Message sent to ${messagingStudent.name}'s parent.`);
                setMessagingStudent(null);
            }}
          />
      )}
      {deletingStudent && user && (
        <DeleteStudentModal
          isOpen={!!deletingStudent}
          onClose={() => setDeletingStudent(null)}
          student={deletingStudent}
          token={user.token}
          onSuccess={handleStudentDeleted}
        />
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 bg-green-500 text-white py-2 px-4 rounded-lg shadow-lg animate-bounce">
          {toastMessage}
        </div>
      )}
    </>
  );
};

export default SchoolDashboard;