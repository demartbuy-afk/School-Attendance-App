import React, { useState } from 'react';

interface SettingsManagerProps {
    showToast: (message: string) => void;
}

const SettingsManager: React.FC<SettingsManagerProps> = ({ showToast }) => {
    const [accountSid, setAccountSid] = useState('');
    const [authToken, setAuthToken] = useState('');
    const [loading, setLoading] = useState(false);

    const handleSaveSms = (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        // Simulate saving the settings
        setTimeout(() => {
            setLoading(false);
            showToast('Settings saved successfully!');
            setAccountSid('');
            setAuthToken('');
        }, 1000);
    };

    return (
        <div>
            <h2 className="text-2xl font-bold text-neutral dark:text-gray-200 mb-6">Settings</h2>
            
            <div className="max-w-2xl">
                <div className="opacity-75">
                    <h3 className="text-lg font-semibold text-neutral dark:text-gray-300 mb-2">SMS Gateway Integration (Simulation)</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                        Configure your SMS provider (e.g., Twilio) to send real-time attendance notifications to parents.
                    </p>

                    <div className="bg-red-50 dark:bg-red-900/30 border-l-4 border-red-500 text-red-700 dark:text-red-200 p-4 rounded-r-lg my-4" role="alert">
                        <p className="font-bold">Important Security Notice</p>
                        <p className="text-sm">
                            This is a **simulation only**. In a real-world application, API keys and auth tokens must be stored securely on a backend server, not in the frontend application. The values you enter below will not be saved or used.
                        </p>
                    </div>

                    <form onSubmit={handleSaveSms} className="space-y-4 bg-gray-50 dark:bg-gray-700/50 p-6 rounded-lg">
                        <div>
                            <label htmlFor="accountSid" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Account SID</label>
                            <input
                                type="text"
                                id="accountSid"
                                value={accountSid}
                                onChange={(e) => setAccountSid(e.target.value)}
                                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-gray-900 dark:text-gray-200 focus:outline-none focus:ring-primary focus:border-primary"
                                placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                            />
                        </div>
                         <div>
                            <label htmlFor="authToken" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Auth Token</label>
                            <input
                                type="password"
                                id="authToken"
                                value={authToken}
                                onChange={(e) => setAuthToken(e.target.value)}
                                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-gray-900 dark:text-gray-200 focus:outline-none focus:ring-primary focus:border-primary"
                                placeholder="••••••••••••••••••••••••••••"
                            />
                        </div>
                        <div className="text-right">
                            <button
                                type="submit"
                                disabled={loading || !accountSid || !authToken}
                                className="px-6 py-2 bg-primary text-white font-semibold rounded-lg shadow-md hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-75 disabled:bg-gray-400 dark:disabled:bg-gray-600"
                            >
                                {loading ? 'Saving...' : 'Save Configuration'}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default SettingsManager;