import React, { useState } from 'react';
import { api } from '../../services/api';
import { School } from '../../types';

interface SubscriptionManagerProps {
    school: School;
    onSubscriptionUpdate: (updatedSchool: School) => void;
    showToast: (message: string) => void;
}

const SubscriptionManager: React.FC<SubscriptionManagerProps> = ({ school, onSubscriptionUpdate, showToast }) => {
    const [loadingPlan, setLoadingPlan] = useState<number | null>(null);

    const plans = [
        { name: 'Monthly', months: 1, price: 599, originalPrice: 599, discount: '' },
        { name: 'Half-Yearly', months: 6, price: 3235, originalPrice: 3594, discount: '10% OFF' },
        { name: 'Yearly', months: 12, price: 5750, originalPrice: 7188, discount: '20% OFF' },
    ];

    const handleChoosePlan = async (months: number) => {
        setLoadingPlan(months);
        try {
            const updatedSchool = await api.updateSubscription(school.token, school.id, months);
            onSubscriptionUpdate(updatedSchool);
        } catch (error) {
            showToast('Failed to update subscription. Please try again.');
        } finally {
            setLoadingPlan(null);
        }
    };
    
    const expiryDate = new Date(school.subscription_expiry_date);
    const isExpired = expiryDate < new Date();

    return (
        <div>
            <h2 className="text-2xl font-bold text-neutral dark:text-gray-200 mb-2">Subscription Management</h2>
            <p className="text-gray-500 dark:text-gray-400 mb-6">Choose a plan to activate or extend your subscription.</p>

            <div className={`p-4 rounded-lg mb-6 text-center ${isExpired ? 'bg-red-100 dark:bg-red-900/50 text-red-800 dark:text-red-200' : 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-200'}`}>
                <p className="font-semibold">
                    {isExpired ? 'Your Subscription has Expired' : 'Your Subscription is Active'}
                </p>
                <p className="text-sm">
                    {isExpired ? `Expired on: ${expiryDate.toLocaleDateString()}` : `Expires on: ${expiryDate.toLocaleDateString()}`}
                </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {plans.map(plan => (
                    <div key={plan.name} className={`border rounded-lg p-6 flex flex-col text-center transition-shadow hover:shadow-lg ${plan.name === 'Yearly' ? 'border-primary' : 'dark:border-gray-700'}`}>
                        {plan.discount && (
                           <div className="text-right -mt-2 -mr-2 mb-2">
                             <span className="bg-secondary text-white text-xs font-bold px-3 py-1 rounded-full">{plan.discount}</span>
                           </div>
                        )}
                        <h3 className="text-xl font-bold text-neutral dark:text-gray-200">{plan.name}</h3>
                        <p className="text-gray-500 dark:text-gray-400 mt-2">{plan.months} Month{plan.months > 1 ? 's' : ''}</p>
                        
                        <div className="my-6">
                            <span className="text-4xl font-extrabold text-neutral dark:text-gray-100">₹{plan.price.toLocaleString()}</span>
                            {plan.originalPrice !== plan.price && (
                                <span className="text-sm text-gray-500 line-through ml-2">₹{plan.originalPrice.toLocaleString()}</span>
                            )}
                        </div>
                        
                        <p className="text-sm text-gray-500 dark:text-gray-400 flex-grow mb-6">
                            Full access to all features including attendance tracking, parent notifications, and student analytics.
                        </p>
                        
                        <button 
                            onClick={() => handleChoosePlan(plan.months)}
                            disabled={loadingPlan === plan.months}
                            className={`w-full py-3 px-4 rounded-lg font-semibold transition-colors disabled:bg-gray-400 dark:disabled:bg-gray-600 ${plan.name === 'Yearly' ? 'bg-primary text-white hover:bg-primary-hover' : 'bg-gray-200 dark:bg-gray-700 text-neutral dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'}`}
                        >
                            {loadingPlan === plan.months ? 'Processing...' : 'Choose Plan'}
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default SubscriptionManager;