import React, { useState } from 'react';
import { api } from '../../services/api';

interface FaceEnrollmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  studentId: string;
  token: string;
  onSuccess: () => void;
}

const FaceEnrollmentModal: React.FC<FaceEnrollmentModalProps> = ({ isOpen, onClose, studentId, token, onSuccess }) => {
  const [step, setStep] = useState<'initial' | 'processing' | 'success' | 'error'>('initial');
  const [errorMessage, setErrorMessage] = useState('');

  const handleEnroll = async () => {
    setStep('processing');
    try {
      await api.enrollFace(studentId, token);
      setStep('success');
    } catch (err) {
      setErrorMessage((err as Error).message);
      setStep('error');
    }
  };
  
  const handleClose = () => {
    if (step === 'success') {
        onSuccess();
    }
    onClose();
    // Reset state for next time
    setTimeout(() => setStep('initial'), 300);
  }

  if (!isOpen) return null;

  const renderContent = () => {
    switch (step) {
      case 'initial':
        return (
          <>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-4">Enroll Your Face</h3>
            <div className="my-6 flex flex-col items-center">
              <div className="w-48 h-48 border-4 border-dashed border-primary rounded-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <p className="text-center text-gray-600 dark:text-gray-400 mt-4">
                This will simulate capturing your face for touchless attendance. Please look directly at the camera.
              </p>
            </div>
          </>
        );
      case 'processing':
        return (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-lg font-semibold text-gray-700 dark:text-gray-300">Processing...</p>
          </div>
        );
      case 'success':
        return (
          <div className="text-center py-12">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-green-500 mx-auto" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            <p className="mt-4 text-lg font-semibold text-green-600 dark:text-green-400">Enrollment Successful!</p>
          </div>
        );
      case 'error':
        return (
          <div className="text-center py-12">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-red-500 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
             </svg>
            <p className="mt-4 text-lg font-semibold text-red-600 dark:text-red-400">Enrollment Failed</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">{errorMessage}</p>
          </div>
        );
    }
  };

  const renderButtons = () => {
      switch (step) {
          case 'initial':
              return (
                  <>
                    <button onClick={handleClose} type="button" className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm hover:bg-gray-50 dark:hover:bg-gray-600">Cancel</button>
                    <button onClick={handleEnroll} type="button" className="px-4 py-2 text-sm font-medium text-white bg-primary rounded-md shadow-sm hover:bg-primary-hover">Enroll</button>
                  </>
              );
          case 'success':
          case 'error':
              return <button onClick={handleClose} type="button" className="px-4 py-2 text-sm font-medium text-white bg-primary rounded-md hover:bg-primary-hover">Done</button>
          default:
              return null;
      }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md">
        <div className="p-6">
          {renderContent()}
        </div>
        <div className="px-6 py-4 bg-gray-50 dark:bg-gray-900 flex justify-end space-x-3">
          {renderButtons()}
        </div>
      </div>
    </div>
  );
};

export default FaceEnrollmentModal;