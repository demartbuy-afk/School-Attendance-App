import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../../services/api';
import { Message } from '../../types';

interface MessageBoardProps {
  studentId: string;
  token: string;
}

const MessageBoard: React.FC<MessageBoardProps> = ({ studentId, token }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMessages = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const fetchedMessages = await api.getMessagesForStudent(studentId, token);
      setMessages(fetchedMessages);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [studentId, token]);

  useEffect(() => {
    fetchMessages();
  }, [fetchMessages]);

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-neutral dark:text-gray-200 mb-4">Messages from School</h2>
      {loading ? (
        <p className="text-center text-gray-500 dark:text-gray-400">Loading messages...</p>
      ) : error ? (
        <p className="text-center text-red-500">{error}</p>
      ) : messages.length === 0 ? (
        <p className="text-center text-gray-500 dark:text-gray-400">No messages from the school yet.</p>
      ) : (
        <div className="space-y-4 max-h-60 overflow-y-auto pr-2">
          {messages.map(message => (
            <div key={message.message_id} className="bg-gray-100 dark:bg-gray-700/50 p-3 rounded-lg">
              <p className="text-sm text-gray-800 dark:text-gray-200">{message.text}</p>
              <p className="text-right text-xs text-gray-500 dark:text-gray-400 mt-2">
                {new Date(message.timestamp).toLocaleString()}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MessageBoard;