import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';
import { StudentAnalytics, Student } from '../../types';
import Header from '../common/Header';
import AnalyticsCard from './AnalyticsCard';
import RecentAttendance from './RecentAttendance';
import FaceEnrollmentModal from './FaceEnrollmentModal';
import ComplaintBox from './ComplaintBox';
import MessageBoard from './MessageBoard';

const StudentDashboard: React.FC = () => {
  const { user } = useAuth();
  const [analytics, setAnalytics] = useState<StudentAnalytics | null>(null);
  const [student, setStudent] = useState<Student | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isEnrollmentModalOpen, setIsEnrollmentModalOpen] = useState(false);

  const fetchData = useCallback(async () => {
    if (user) {
      setLoading(true);
      setError(null);
      try {
        const [analyticsData, studentData] = await Promise.all([
          api.getStudentAnalytics(user.id, user.token),
          api.getStudentById(user.id, user.token)
        ]);
        setAnalytics(analyticsData);
        setStudent(studentData);
      } catch (err) {
        setError((err as Error).message);
      } finally {
        setLoading(false);
      }
    }
  }, [user]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);
  
  const handleEnrollmentSuccess = () => {
    fetchData(); // Refresh student data to show updated status
    setIsEnrollmentModalOpen(false);
  }

  return (
    <>
      <Header />
      <main className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        {loading ? (
          <div className="flex items-center justify-center pt-20">
            <div className="animate-spin rounded-full h-24 w-24 border-t-2 border-b-2 border-primary"></div>
          </div>
        ) : error ? (
          <div className="text-center text-red-500 bg-red-100 dark:bg-red-900 dark:text-red-200 p-4 rounded-lg">{error}</div>
        ) : student && analytics ? (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <AnalyticsCard title="Days Present" value={analytics.present_count.toString()} color="green" />
              <AnalyticsCard title="Days Absent" value={analytics.absent_count.toString()} color="red" />
              <AnalyticsCard title="Last Entry" value={analytics.last_entry || 'N/A'} color="blue" />
              <AnalyticsCard title="Last Exit" value={analytics.last_exit || 'N/A'} color="yellow" />
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h2 className="text-2xl font-bold text-neutral dark:text-gray-200 mb-4">Recent Activity (Last 7 Days)</h2>
                <RecentAttendance logs={analytics.recent_logs} />
              </div>

              <div className="space-y-8">
                 <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md flex flex-col justify-center items-center text-center">
                    <h2 className="text-2xl font-bold text-neutral dark:text-gray-200 mb-4">Face Enrollment</h2>
                    {student.face_enrolled ? (
                        <>
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-green-500" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                          </svg>
                          <p className="mt-2 font-semibold text-green-600 dark:text-green-400">You are enrolled!</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Face recognition is active for your account.</p>
                        </>
                    ) : (
                        <>
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <p className="mt-2 font-semibold text-gray-700 dark:text-gray-300">Not Enrolled</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Enroll to use touchless attendance.</p>
                            <button onClick={() => setIsEnrollmentModalOpen(true)} className="mt-4 px-6 py-2 bg-secondary text-white font-semibold rounded-lg shadow-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-secondary focus:ring-opacity-75">
                                Enroll Now
                            </button>
                        </>
                    )}
                </div>
                {user && <MessageBoard studentId={user.id} token={user.token} />}
                {user && <ComplaintBox studentId={user.id} token={user.token} />}
              </div>
            </div>
          </div>
        ) : (
            <p className="text-center text-gray-500 dark:text-gray-400">No data available.</p>
        )}
      </main>
      
      {isEnrollmentModalOpen && user && (
          <FaceEnrollmentModal 
              isOpen={isEnrollmentModalOpen}
              onClose={() => setIsEnrollmentModalOpen(false)}
              studentId={user.id}
              token={user.token}
              onSuccess={handleEnrollmentSuccess}
          />
      )}
    </>
  );
};

export default StudentDashboard;