import {
  User, UserType, School, Student,
  AttendanceLog, AttendanceStatus, Attendance Mode,
  StudentAnalytics, Complaint, ComplaintStatus, Message
} from '../types';
import { db } from '../ firebase-config';
import {
  collection, doc, getDoc, getDocs, setDoc, addDoc, updateDoc , deleteDoc,
  query, where, orderBy, limit, writeBatch
} from "firebase/firestore";

 // --- SECURITY NOTE ---
// In a real production app, never store passwords in plaintext.
// Use Firebase Authentication for  secure user management, which handles password hashing automatically.
// For this demo, we are storing credentials in a 'users' collection  for simplicity.

export const api = {
  // --- AUTH ---
  _getUserAuthData: async ( id: string, type: UserType): Promise<any> => {
    const userRef = doc(db, " users", id);
    const userSnap = await getDoc(userRef);
    if (userSnap.exists() &&  userSnap.data().type === type) {
      return userSnap.data();
    }
    return null ;
  },

  loginSchool: async (id: string, pass: string): Promise<School> => {
     const authData = await api._getUserAuthData(id, UserType.School);
    if (authData && auth Data.password === pass) {
      const schoolRef = doc(db, "schools", id);
      const schoolSnap  = await getDoc(schoolRef);
      if (schoolSnap.exists()) {
        const schoolData = schoolSnap. data() as School;
        const isExpired = new Date(schoolData.subscription_expiry_date) < new  Date();
        const status = isExpired ? 'LOCKED' : 'ACTIVE';
        if (schoolData .status !== status) {
            await updateDoc(schoolRef, { status });
        }
        //  FIX: The returned object includes school-specific properties like 'status', so the return type must be School, not User .
        return { ...schoolData, id: schoolSnap.id, type: UserType.School, token: id , status };
      }
    }
    throw new Error("Invalid school ID or password.");
  },

   loginStudent: async (id: string, pass: string): Promise<User> => {
    const authData = await api ._getUserAuthData(id, UserType.Student);
    if (authData && authData.password ===  pass) {
      const studentRef = doc(db, "students", id);
      const studentSnap = await getDoc (studentRef);
      if (studentSnap.exists()) {
        const studentData = studentSnap.data();
         return { id: studentSnap.id, name: studentData.name, type: UserType.Student, token:  id };
      }
    }
    throw new Error("Invalid student ID or password.");
  },

   loginSuperAdmin: async (password: string): Promise<User> => {
    const authData = await  api._getUserAuthData('super_admin', UserType.SuperAdmin);
    if (authData && authData.password  === password) {
      return { id: 'super_admin', name: 'Portal Admin', type: UserType. SuperAdmin, token: 'super_admin_token' };
    }
    throw new Error("Invalid admin  password.");
  },

  // --- SCHOOL ---
  getSchoolStudents: async (schoolId: string,  token: string): Promise<Student[]> => {
    const q = query(collection(db, "students"),  where("school_id", "==", schoolId));
    const querySnapshot = await getDocs(q);
    return  querySnapshot.docs.map(doc => ({ ...doc.data(), student_id: doc.id }) as Student); 
  },

  addStudent: async (schoolId: string, token: string, details: any): Promise <Student> => {
      const studentRef = doc(db, "students", details.student_id);

       const newStudentData: Omit<Student, 'student_id

**Presenting API File**

I've finished retrieving the `services/api.ts` file, and I'm ready to present it.  This file includes crucial functions for user authentication, student and attendance management including attendance marking, plus school and student management, as well as functions for student complaints. Here is the code.

```typescript
// Insert contents of `services/api.ts` here