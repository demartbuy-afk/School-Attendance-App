export enum UserType {
  School = 'school',
  Student = 'student',
  SuperAdmin = 'super_admin'
}

export interface User {
  id: string;
  name: string;
  type: UserType;
  token: string;
}

export interface School extends User {
  type: UserType.School;
  address: string;
  contact_no: string;
  status: 'ACTIVE' | 'LOCKED';
  subscription_expiry_date: string;
  student_count?: number; // Optional as it might be calculated
  password?: string; // only on creation
}

export interface Student {
  student_id: string;
  school_id: string;
  name: string;
  roll_no: string;
  class: string;
  parent_phone: string;
  face_enrolled: boolean;
  qr_value: string;
  total_fees: number;
  fees_paid: number;
  password_auto?: string; // from add student modal
}

export enum AttendanceStatus {
  IN = 'IN',
  OUT = 'OUT',
  ABSENT = 'ABSENT'
}

export enum AttendanceMode {
  MANUAL = 'MANUAL',
  QR = 'QR',
  FACE = 'FACE'
}

export interface AttendanceLog {
  log_id: string;
  student_id: string;
  student_name: string;
  school_id: string;
  timestamp: string;
  status: AttendanceStatus;
  mode: AttendanceMode;
}

export interface StudentAnalytics {
  present_count: number;
  absent_count: number;
  last_entry: string | null;
  last_exit: string | null;
  recent_logs: AttendanceLog[];
}

export enum ComplaintStatus {
    OPEN = 'OPEN',
    RESOLVED = 'RESOLVED'
}

export interface Complaint {
    complaint_id: string;
    student_id: string;
    student_name: string;
    school_id: string;
    text: string;
    timestamp: string;
    status: ComplaintStatus;
}

export interface Message {
    message_id: string;
    student_id: string;
    school_id: string;
    text: string;
    timestamp: string;
}